// Sets the flow variable flow.resouce from the pathsuffix, it's used in error responses.
// If you use the proxy.pathsuffix directly you will also get the / in the name
// this is called in the default PreFlow

var flowtype = context.getVariable("flow.type");

if(flowtype === null){
    var pathsuffix = context.getVariable("proxy.pathsuffix");
    /* Remove leading forward slash */
    var targetURL = pathsuffix.replace(/^\/|\/$/g, '');  
    context.setVariable("flow.resource", targetURL);    
}

