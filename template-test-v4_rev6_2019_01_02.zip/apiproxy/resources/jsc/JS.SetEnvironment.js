var proxyEnv= context.getVariable("environment.name");
var customEnv= context.getVariable("app.route-to-backend");

if (proxyEnv.toLowerCase() == "stage"){
    if(customEnv !==null && customEnv !== "" && (customEnv.toUpperCase() =="SIT" || customEnv.toUpperCase() =="UAT"  )){
        print("Inside stage env. Setting header env="+customEnv);
        context.setVariable("request.header.env", customEnv );
    }else{
        print("Inside stage env. Setting header env to default environment="+proxyEnv);
        context.setVariable("request.header.env", proxyEnv );
    }
}
else{
    print("Inside "+proxyEnv+" env. Setting header env to default Env.="+proxyEnv);
    context.setVariable("request.header.env", proxyEnv );
}