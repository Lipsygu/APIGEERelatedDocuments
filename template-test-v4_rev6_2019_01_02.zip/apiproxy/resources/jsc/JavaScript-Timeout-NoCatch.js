function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

 var error = context.getVariable("exate.error");

if(error != 'TRUE'){

    var bodyObj = {
        'grant_type': 'password',
        'username': 'user1',
        'password': 'password1',
        'client_id': 'SecowserNativeApp',
        'client_secret': 'ccca448C991&%9427ebd76f4D88E9B0@060=='
      };
    
    //pairs = Object.keys(formValues).map(makeFormEncoder(formValues));
    
    print("Inside timeout without catch");
    
 
       var req = new Request('https://httpbin.org/get'); 
       //var req = new Request('https://auth.exatetechnology.com/token', 'POST', {'Content-Type':'application/x-www-form-urlencoded'}, pairs.join('&'));  
        var exchange = httpClient.send(req);
        
      // Wait for the asynchronous POST request to finish
        exchange.waitForComplete();
        print("Inside timeout without  catch. waitForComplete Done !! ");
        sleep(300);
        if (exchange.isSuccess()) {
            //print("The exchange is " + exchange.getResponse().content);
            var responseObj = exchange.getResponse().content.asJSON;
            
            context.setVariable("exate.error", 'FALSE');
            print("Inside timeout without  catch. isSuccess Done !! ");
            
        } else {
            print("Inside timeout without  catch. isSuccess Failed!! ");
            context.setVariable("exate.error", 'TRUE');
            print("The error is " + exchange.getError());
            print("The response was " + exchange.status);
        }
        
 
}